import logging
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.middleware import CorrelationIdMiddleware
from app.routers import chat, tools

logging.basicConfig(level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO))
app = FastAPI(title=settings.APP_NAME)
app.mount("/static", StaticFiles(directory="app/static"), name="static")
app.add_middleware(CorrelationIdMiddleware)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.include_router(chat.router)
app.include_router(tools.router)

@app.get("/")
def root():
    return {"app": settings.APP_NAME, "env": settings.APP_ENV}
