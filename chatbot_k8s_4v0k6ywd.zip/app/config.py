import os

class Settings:
    APP_NAME: str = os.getenv("APP_NAME", "ChatBot")
    APP_ENV: str = os.getenv("APP_ENV", "staging")
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    ENABLE_EMAIL_LOOKUP: str = os.getenv("ENABLE_EMAIL_LOOKUP", "true")
    EMAIL_API_BASE: str = os.getenv("EMAIL_API_BASE", "")
    EMAIL_API_KEY: str = os.getenv("EMAIL_API_KEY", "")
    BASE_PATH: str = os.getenv("BASE_PATH", "/")

settings = Settings()
