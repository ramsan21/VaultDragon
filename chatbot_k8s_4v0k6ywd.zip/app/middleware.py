import logging, uuid
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

logger = logging.getLogger("uvicorn.access")

class CorrelationIdMiddleware(BaseHTTPMiddleware):
    CORRELATION_HEADER = "X-Correlation-ID"

    async def dispatch(self, request: Request, call_next):
        cid = request.headers.get(self.CORRELATION_HEADER) or str(uuid.uuid4())
        request.state.correlation_id = cid
        logger.info(f"[{cid}] IN {request.method} {request.url.path}")
        response = await call_next(request)
        response.headers[self.CORRELATION_HEADER] = cid
        logger.info(f"[{cid}] OUT {response.status_code} {request.url.path}")
        return response
