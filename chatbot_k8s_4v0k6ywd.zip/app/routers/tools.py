from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from app.config import settings
from app.services.email_lookup import lookup

templates = Jinja2Templates(directory="app/templates")
router = APIRouter(prefix="/tools")

@router.get("/check-email", response_class=HTMLResponse)
async def check_email_form(request: Request):
    return templates.TemplateResponse("check_email_form.html", {"request": request, "enabled": settings.ENABLE_EMAIL_LOOKUP.lower() == "true"})

@router.post("/check-email", response_class=HTMLResponse)
async def check_email_submit(request: Request, email: str = Form(default=""), tracking_id: str = Form(default="")):
    if not email and not tracking_id:
        return templates.TemplateResponse("check_email_form.html", {"request": request, "error": "Enter an Email ID or a Tracking ID.", "enabled": settings.ENABLE_EMAIL_LOOKUP.lower() == "true"})
    result = lookup(email=email or None, tracking_id=tracking_id or None)
    return templates.TemplateResponse("check_email_result.html", {"request": request, "result": result})
