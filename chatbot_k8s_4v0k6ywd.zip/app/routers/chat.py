from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

templates = Jinja2Templates(directory="app/templates")
router = APIRouter()

COMMANDS = [("/help", "List available commands"),
            ("/chat?msg=hello", "Send a simple chat message"),
            ("/tools/check-email", "Open the Email/Tracking form")]

@router.get("/help", response_class=HTMLResponse)
async def help_page(request: Request):
    return templates.TemplateResponse("help.html", {"request": request, "commands": COMMANDS})

@router.get("/chat", response_class=HTMLResponse)
async def chat(request: Request, msg: str = "hi"):
    reply = f"You said: {msg}. Try /help for commands."
    return templates.TemplateResponse("index.html", {"request": request, "user_msg": msg, "bot_reply": reply})
