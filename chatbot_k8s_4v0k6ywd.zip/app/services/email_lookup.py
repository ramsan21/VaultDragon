from typing import Optional

def lookup(email: Optional[str] = None, tracking_id: Optional[str] = None) -> dict:
    if email:
        return {"type": "email", "query": email, "status": "OK", "found": True,
                "details": {"inbox_unread": 2, "last_message_from": "notifications@example.com"}}
    if tracking_id:
        return {"type": "tracking", "query": tracking_id, "status": "OK", "found": True,
                "details": {"stage": "In Transit", "eta": "2 business days"}}
    return {"status": "ERROR", "message": "Provide email or tracking_id."}
